'use client';

import * as stylex from '@stylexjs/stylex';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { FaArrowLeft } from 'react-icons/fa6';
import { HiOutlineVideoCamera } from 'react-icons/hi2';
import { IoCallOutline, IoInformationCircleOutline } from 'react-icons/io5';
import { sendImage } from '@/src/actions/dm/sendImage';
import { sendMessage } from '@/src/actions/dm/sendMessage';
import { sendSticker } from '@/src/actions/dm/sendSticker';
import { sendVoiceMessage } from '@/src/actions/dm/sendVoiceMessage';
import { toast } from '@/src/components/AppToast';
import UserAvatar from '@/src/components/UserAvatar';
import OtherUserUsername from '@/src/components/Username/OtherUserUsername';
import { useInfiniteScrollSentinel } from '@/src/hooks/useInfiniteScrollSentinel';
import { useSendMessage } from '@/src/hooks/useSendMessage';
import { queryKeys, staleTime } from '@/src/lib/queryKeys';
import { supabase } from '@/src/lib/supabase/client';
import { type ConversationDetail, getConversationQuery } from '@/src/queries/conversations';
import type { ConversationMessage, ConversationMessages } from '@/src/queries/messages';
import { compressMessageImage } from '@/src/utils/compressMessageImage';
import {
   getConversationAvatars,
   getConversationDisplayName,
   isGroupConversation,
} from '@/src/utils/conversations';
import { styles } from '../../index.stylex';
import { useChatScrollAndRead } from './hooks/useChatScrollAndRead';
import { useMessageWindow } from './hooks/useMessageWindow';
import { useObjectUrls } from './hooks/useObjectUrls';
import { useRealtimeChat } from './hooks/useRealtimeChat';
import ImageViewModal from './ImageViewModal';
import MessageInput, { type MessageInputHandle } from './MessageInput';
import MessageList from './MessageList';
import RequestActions from './RequestActions';
import VoiceRecorder from './VoiceRecorder';

interface ChatViewProps {
   conversationId: string;
   authUserId: string;
   folder: 'primary' | 'general' | 'requests';
   currentFolderHref: string;
   initialMessages: ConversationMessages;
   initialConversation: ConversationDetail;
   onInfoClick: () => void;
}

export default function ChatView({
   conversationId,
   authUserId,
   folder,
   currentFolderHref,
   initialMessages,
   initialConversation,
   onInfoClick,
}: ChatViewProps) {
   const queryClient = useQueryClient();
   const messagesEndRef = useRef<HTMLDivElement>(null);
   const messagesContainerRef = useRef<HTMLDivElement>(null);
   const inputRef = useRef<MessageInputHandle>(null);
   const [viewingImage, setViewingImage] = useState<string | null>(null);
   const [isRecording, setIsRecording] = useState(false);
   const send = useSendMessage(conversationId);
   const createObjectUrl = useObjectUrls();

   const { getRootProps, isDragActive } = useDropzone({
      noClick: true,
      noKeyboard: true,
      accept: { 'image/*': [] },
      maxSize: 25 * 1024 * 1024,
      onDrop: accepted => {
         if (accepted.length) inputRef.current?.addFiles(accepted);
      },
      onDropRejected: rejections => {
         for (const r of rejections) toast(`${r.file.name} is too large or not an image`);
      },
   });

   const { messages, loadOlderMessages, hasOlderMessages, isLoadingOlder } = useMessageWindow({
      conversationId,
      initialMessages,
      containerRef: messagesContainerRef,
   });

   const olderMessagesSentinelRef = useInfiniteScrollSentinel({
      hasNextPage: hasOlderMessages,
      isFetchingNextPage: isLoadingOlder,
      fetchNextPage: loadOlderMessages,
      rootMargin: '300px 0px 0px 0px',
   });

   const { data: conversation = initialConversation } = useQuery({
      queryKey: queryKeys.conversation(conversationId),
      queryFn: async () => {
         const { data, error } = await getConversationQuery(supabase, conversationId);
         if (error) throw error;
         return data;
      },
      initialData: initialConversation,
      staleTime: staleTime.never,
   });

   useRealtimeChat(conversationId, queryClient);

   useChatScrollAndRead({
      containerRef: messagesContainerRef,
      endRef: messagesEndRef,
      messages,
      conversationId,
      authUserId,
      initialConversation,
   });

   const participants = conversation?.participants ?? [];
   const authProfile = participants.find(p => p.user_id === authUserId)?.user;
   const displayName = getConversationDisplayName(participants, authUserId, conversation?.title);
   const avatars = getConversationAvatars(participants, authUserId);
   const isGroup = isGroupConversation(participants);
   const isRequest = folder === 'requests';
   const otherParticipant = participants.find(p => p.user_id !== authUserId)?.user;

   function createOptimisticMessage(overrides: Partial<ConversationMessage>) {
      const id = `optimistic-${Date.now()}`;
      return {
         id,
         content: null,
         call_event: null,
         sticker_url: null,
         media_url: null,
         audio_url: null,
         story_id: null,
         post_id: null,
         post: null,
         created_at: new Date().toISOString(),
         sender_id: authUserId,
         is_deleted: false,
         reply_to_id: null,
         read_at: null,
         story: null,
         sender: authProfile ?? {
            id: authUserId,
            username: '',
            full_name: null,
            avatar_url: null,
         },
         ...overrides,
      } satisfies ConversationMessage;
   }

   return (
      <div {...getRootProps()} {...stylex.props(styles.chatViewRoot)}>
         <div {...stylex.props(styles.chatTopBar)}>
            <div {...stylex.props(styles.chatTopBarRecipient)}>
               <Link
                  href={currentFolderHref}
                  {...stylex.props(styles.backButton)}
                  aria-label="Back to messages"
               >
                  <FaArrowLeft {...stylex.props(styles.backButtonIcon)} />
               </Link>
               <UserAvatar
                  src={avatars[0]?.avatar_url ?? null}
                  alt={displayName}
                  size={44}
                  username={avatars[0]?.username ?? ''}
                  userId={avatars[0]?.id}
               />
               <div>
                  <div {...stylex.props(styles.chatTopBarRecipientName)}>{displayName}</div>
                  {!isGroup && otherParticipant && (
                     <OtherUserUsername
                        style={styles.chatTopBarRecipientUsername}
                        userProfile={otherParticipant}
                     />
                  )}
               </div>
            </div>
            <div {...stylex.props(styles.chatTopBarActions)}>
               <Link
                  href={`${currentFolderHref}/${conversationId}/call?type=audio`}
                  {...stylex.props(styles.chatTopBarActionIcon)}
                  aria-label="Voice call"
               >
                  <IoCallOutline />
               </Link>
               <Link
                  href={`${currentFolderHref}/${conversationId}/call?type=video`}
                  {...stylex.props(styles.chatTopBarActionIcon)}
                  aria-label="Video call"
               >
                  <HiOutlineVideoCamera />
               </Link>
               <button
                  type="button"
                  onClick={onInfoClick}
                  aria-label="Conversation details"
                  {...stylex.props(styles.chatTopBarActionIcon)}
               >
                  <IoInformationCircleOutline />
               </button>
            </div>
         </div>

         {isDragActive && (
            <div {...stylex.props(styles.dropOverlay)}>
               <span {...stylex.props(styles.dropTitle)}>Drop files here</span>
               <span {...stylex.props(styles.dropSubtitle)}>max 25 MB</span>
            </div>
         )}

         <div ref={messagesContainerRef} {...stylex.props(styles.messagesContainer)}>
            {hasOlderMessages && <div ref={olderMessagesSentinelRef} />}

            {!isGroup && !hasOlderMessages && otherParticipant && (
               <div {...stylex.props(styles.chatProfileHeader)}>
                  <UserAvatar
                     src={otherParticipant.avatar_url}
                     alt={otherParticipant.username}
                     size={96}
                     username={otherParticipant.username}
                     userId={otherParticipant.id}
                  />
                  <OtherUserUsername
                     style={styles.chatProfileUsername}
                     userProfile={otherParticipant}
                  />
                  <div {...stylex.props(styles.chatProfileSubtitle)}>Clonagram</div>
                  <Link
                     href={`/profile/${otherParticipant.username}`}
                     {...stylex.props(styles.chatProfileButton)}
                  >
                     View profile
                  </Link>
               </div>
            )}

            <MessageList
               messages={messages}
               authUserId={authUserId}
               onOpenImage={setViewingImage}
            />
            <div ref={messagesEndRef} />
         </div>

         {isRequest ? (
            <RequestActions
               conversationId={conversationId}
               authUserId={authUserId}
               senderUserId={participants.find(p => p.user_id !== authUserId)?.user_id ?? ''}
               senderProfile={otherParticipant ?? null}
            />
         ) : isRecording ? (
            <VoiceRecorder
               onCancel={() => setIsRecording(false)}
               onSend={async (blob: Blob) => {
                  const previewUrl = createObjectUrl(blob);
                  await send(
                     () => createOptimisticMessage({ audio_url: previewUrl }),
                     async () => {
                        const fileName = `${crypto.randomUUID()}.webm`;
                        const { error: uploadError } = await supabase.storage
                           .from('messages')
                           .upload(fileName, blob, { contentType: blob.type || 'audio/webm' });
                        if (uploadError) throw uploadError;
                        const { data: urlData } = supabase.storage
                           .from('messages')
                           .getPublicUrl(fileName);
                        await sendVoiceMessage(conversationId, urlData.publicUrl);
                     },
                     'Failed to send voice message',
                  );
                  setIsRecording(false);
               }}
            />
         ) : (
            <MessageInput
               ref={inputRef}
               onStartRecording={() => setIsRecording(true)}
               onSendSticker={async (url: string) => {
                  await send(
                     () => createOptimisticMessage({ sticker_url: url }),
                     () => sendSticker(conversationId, url),
                     'Failed to send sticker',
                  );
               }}
               onSend={async text => {
                  await send(
                     () => createOptimisticMessage({ content: text }),
                     () => sendMessage(conversationId, text),
                     'Failed to send message',
                  );
               }}
               onSendImages={async (files: File[]) => {
                  for (const file of files) {
                     const previewUrl = createObjectUrl(file);
                     await send(
                        () => createOptimisticMessage({ media_url: previewUrl }),
                        async () => {
                           const blob = await compressMessageImage(file);
                           const fileName = `${crypto.randomUUID()}.webp`;
                           const compressed = new File([blob], fileName, { type: 'image/webp' });
                           const { error: uploadError } = await supabase.storage
                              .from('messages')
                              .upload(fileName, compressed);
                           if (uploadError) throw uploadError;
                           const { data: urlData } = supabase.storage
                              .from('messages')
                              .getPublicUrl(fileName);
                           await sendImage(conversationId, urlData.publicUrl);
                        },
                        'Failed to send image',
                     );
                  }
               }}
            />
         )}

         <ImageViewModal
            src={viewingImage}
            open={!!viewingImage}
            onClose={() => setViewingImage(null)}
         />
      </div>
   );
}
