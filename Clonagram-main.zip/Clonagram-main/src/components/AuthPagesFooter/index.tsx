import * as stylex from '@stylexjs/stylex';
import Link from 'next/link';
import { MdKeyboardArrowDown } from 'react-icons/md';
import { styles } from './index.stylex';

export const footerLinks = [
   'Zeta',
   'About',
   'Blog',
   'Jobs',
   'Help',
   'API',
   'Privacy',
   'Cookie Settings',
   'Terms',
   'Locations',
   'Clonagram Lite',
   'Zeta AI',
   'Threads',
   'Contact Uploading & Non-Users',
   'Zeta Verified',
] as const;

export default function AuthPagesFooter({ ...props }: React.ComponentProps<'footer'>) {
   return (
      <footer {...stylex.props(styles.root)} {...props}>
         <div {...stylex.props(styles.footerLinks)}>
            {footerLinks.map(item => (
               <Link key={item} href="/" {...stylex.props(styles.footerLink)}>
                  {item}
               </Link>
            ))}
         </div>
         <div {...stylex.props(styles.footerMetaRow)}>
            <button type="button" {...stylex.props(styles.languageButton)}>
               English
               <MdKeyboardArrowDown size={14} />
            </button>
            <span>© {new Date().getFullYear()} Clonagram from Zeta</span>
         </div>
      </footer>
   );
}
