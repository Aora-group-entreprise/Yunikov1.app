'use server';
import 'server-only';
import { randomUUID } from 'node:crypto';
import { getAuthUser } from '@/src/actions/getAuthUser';
import { throwIfError } from '@/src/lib/unwrap';
import { CreateConversationSchema, validate } from '@/src/lib/validation';
import { findOrCreateDirectConversation } from './findOrCreateDirectConversation';

export async function createConversation(participantIds: string[]) {
   const { participantIds: validatedParticipantIds } = validate(CreateConversationSchema, {
      participantIds,
   });
   const { supabase, user } = await getAuthUser();

   const uniqueParticipantIds = [...new Set(validatedParticipantIds.filter(id => id !== user.id))];

   if (uniqueParticipantIds.length === 1) {
      return findOrCreateDirectConversation(supabase, user.id, uniqueParticipantIds[0]);
   }

   const convId = randomUUID();
   const { error: convError } = await supabase
      .from('conversations')
      .insert({ id: convId, title: null });
   throwIfError({ error: convError }, 'Failed to create conversation');

   const { data: followers } = await supabase
      .from('follows')
      .select('follower_id')
      .in('follower_id', uniqueParticipantIds)
      .eq('following_id', user.id)
      .eq('status', 'accepted');
   const followerSet = new Set((followers ?? []).map(r => r.follower_id));

   const participants = [
      { conversation_id: convId, user_id: user.id, role: 'admin', folder: 'primary' },
      ...uniqueParticipantIds.map(uid => ({
         conversation_id: convId,
         user_id: uid,
         role: 'member',
         folder: followerSet.has(uid) ? 'primary' : 'requests',
      })),
   ];

   const { error: partError } = await supabase
      .from('conversation_participants')
      .insert(participants);
   throwIfError({ error: partError }, 'Failed to add participants');

   return convId;
}
